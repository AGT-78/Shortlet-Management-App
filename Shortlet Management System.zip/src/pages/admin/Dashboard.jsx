


const Dashboard = () => {
  return (
    <div >
      Dashboard Component
    </div>
  );
};

export default Dashboard;