import ViewGuestComp from "../../components/admin/ViewGuestComp";


const ViewBookings = () => {
  return (
    <ViewGuestComp/>
  );
};

export default ViewBookings;