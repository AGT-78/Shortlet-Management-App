

const ViewGuest = () => {
  return (
    <div>
      ViewGuest Component
    </div>
  );
};

export default ViewGuest;