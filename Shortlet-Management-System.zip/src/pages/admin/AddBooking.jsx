


const AddBooking = () => {
  return (
    <div>
      AddBooking Component
    </div>
  );
};

export default AddBooking;