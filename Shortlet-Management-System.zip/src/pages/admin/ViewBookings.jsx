import ViewBookingsComp from "../../components/admin/ViewBookingsComp";


const ViewBookings = () => {
  return (
    <ViewBookingsComp/>
  );
};

export default ViewBookings;