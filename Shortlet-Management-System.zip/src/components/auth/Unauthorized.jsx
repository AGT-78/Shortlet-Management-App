


const Unauthorized = () => {
  return (
    <div>
      Unauthorized Component
    </div>
  );
};

export default Unauthorized;